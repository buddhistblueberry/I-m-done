import xbmc,xbmcgui,xbmcplugin,sys,urllib.parse
handle=int(sys.argv[1])
params=dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

if params.get('action')=='search':
    kb=xbmc.Keyboard('','Search LookMovie')
    kb.doModal()
    if kb.isConfirmed():
        q=urllib.parse.quote(kb.getText())
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.lookmovie/?action=search&query=%s)'%q)
else:
    li=xbmcgui.ListItem('Search LookMovie')
    url=sys.argv[0]+'?action=search'
    xbmcplugin.addDirectoryItem(handle,url,li,False)
    xbmcplugin.endOfDirectory(handle)
